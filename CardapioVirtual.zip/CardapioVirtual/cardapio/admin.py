from django.contrib import admin
from .models import Cardapio
# Register your models here.

admin.site.register(Cardapio)