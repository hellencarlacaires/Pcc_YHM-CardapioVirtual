from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.urls import reverse 
from .models import Cardapio
from prato.models import Prato
from restaurante.models import Restaurante
from prato.views import novo_item
from .forms import Cardapio_form, Editar_cardapio_form
# Create your views here.
def listar_cardapios(request):
    pesquisa = request.GET.get('search')

    if pesquisa:
        a = Cardapio.objects.filter(Nome__icontains=pesquisa)
    else:
        a = Cardapio.objects.all()

    context={
        'cardapio': a
    }
    return render(request, 'lista_cardapios.html', context)

def detalhe_cardapio(request, id):
    a = get_object_or_404(Cardapio, pk=id)
    prato = Prato.objects.filter(Cardapio=a)
    Comidas = Prato.objects.filter(Cardapio=a, Categoria='Comidas')
    Bebidas = Prato.objects.filter(Cardapio=a, Categoria='Bebidas')
    Sobremesas = Prato.objects.filter(Cardapio=a, Categoria='Sobremesas')
    context={
        'cardapio': a,
        'prato': prato,
        'comidas' : Comidas,
        'bebidas': Bebidas,
        'sobremesas' : Sobremesas
    }
    return render(request, 'detalhes_cardapio.html', context)

@login_required
def detalhe_meu_cardapio(request, id):
    a = get_object_or_404(Cardapio, pk=id)
    prato = Prato.objects.filter(Cardapio=a)
    context={
        'cardapio': a,
        'prato': prato
    }
    return render(request, 'detalhes_meu_cardapio.html', context)

@login_required
def criar_cardapio(request, id): 
    a = get_object_or_404(Restaurante, pk=id)   
    if request.method =='POST':
        form = Cardapio_form(request.POST)

        if form.is_valid():
            c = form.save(commit=False)
            c.user = request.user
            c.save()
            b = get_object_or_404(Cardapio, Restaurante=a)
            return redirect(reverse('novo_item', args=[b.id]))
    else:
        form = Cardapio_form
        context= {
            'form':form,
            'restaurante': a
        }
        return render(request, 'criar_cardapio.html', context)

@login_required
def deletar_cardapio(resquest, id):
    Cardapio.objects.get(pk=id).delete()
    return redirect('/restaurante/home/')

@login_required
def editar(request, id):
    C = get_object_or_404(Cardapio, pk=id)
    form = Editar_cardapio_form(instance=C)

    context ={
        'form': form, 
        'cardapio': C
    }

    if request.method == 'POST':
        form = Editar_cardapio_form(request.POST, instance=C)

        if form.is_valid():
            C.save()
            return redirect('/')
        else:
            return render(request, 'editar_cardapio.html', context)   
    else:
        return render(request, 'editar_cardapio.html', context)
