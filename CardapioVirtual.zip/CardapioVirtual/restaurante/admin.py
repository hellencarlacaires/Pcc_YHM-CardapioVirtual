from django.contrib import admin
from .models import Restaurante
# Register your models here.

admin.site.register(Restaurante)