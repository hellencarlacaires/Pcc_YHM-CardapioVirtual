$(document).ready(function(){

    var searchBtn = $('#buscar-btn');
    var searchForm = $('#buscarForm');

    $(searchBtn).on('click', function(){
        searchForm.submit();
    })
});
