
from django.urls import include, path
from . import views
 

urlpatterns = [
    path('<int:id>/novo_item/', views.novo_item, name='novo_item'), 
    path('<int:id_cardapio>/editar_item/<int:id_item>/', views.editar_item, name='editar_item'),
    path('<int:id_cardapio>/deletar_item/<int:id_item>/', views.deletar_item, name='deletar_item'),
]


   