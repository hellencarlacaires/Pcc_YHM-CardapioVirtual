from django.contrib import admin
from .models import Prato
# Register your models here.

admin.site.register(Prato)