from django import forms 
from .models import Prato

class Novo_item_form(forms.ModelForm):
    class Meta:
        model= Prato
        fields = ('Nome', 'Ingredientes', 'Preço', 'Categoria','Cardapio', )

class Editar_item_form(forms.ModelForm):
    class Meta:
        model= Prato
        fields = ('Nome', 'Ingredientes', 'Preço', 'Categoria')