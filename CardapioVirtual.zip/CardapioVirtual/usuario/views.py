from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic 
from django.contrib.auth import get_user_model
from restaurante.views import criar 
from cardapio.models import Cardapio

class cadastro(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('login')
    template_name = 'cadastro.html'

def inicio(request):
    pesquisa = request.GET.get('search')

    if pesquisa:
        a = Cardapio.objects.filter(Nome__icontains=pesquisa)
    else:
        a = Cardapio.objects.all()

    context={
        'cardapio': a
    }
    return render(request, 'index.html', context)